function connectSupplier(name) {
  alert("✅ Connection request sent to " + name + "!");
}

document.getElementById("requestForm").addEventListener("submit", function (e) {
  e.preventDefault();
  
  const material = document.getElementById("material").value;
  const quantity = document.getElementById("quantity").value;
  const location = document.getElementById("location").value;

  document.getElementById("requestStatus").innerText =
    `✅ Request submitted for ${quantity} Kg of ${material} from ${location}.`;

  this.reset();
});

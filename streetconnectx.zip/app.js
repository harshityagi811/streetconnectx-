const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => res.render('home'));
app.get('/dashboard', (req, res) => res.render('dashboard'));
app.get('/orders', (req, res) => res.render('orders'));
app.get('/suppliers', (req, res) => res.render('suppliers'));
app.get('/group-buying', (req, res) => res.render('groupBuying'));
app.get('/chat-support', (req, res) => res.render('chatSupport'));
app.get('/profile', (req, res) => res.render('profile'));

app.post('/connect-supplier', (req, res) => {
  const supplier = req.body.supplier;
  res.send(`You are now connected with ${supplier}`);
});

app.post('/request-material', (req, res) => {
  const { material, quantity } = req.body;
  res.send(`Request submitted for ${quantity}kg of ${material}`);
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));
